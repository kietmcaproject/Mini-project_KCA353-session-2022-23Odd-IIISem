package com.airxstudio.nssps.Activity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.airxstudio.nssps.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;

public class StudentDetailsActivity extends AppCompatActivity {
    AutoCompleteTextView Class;
    FirebaseAuth mAuth;
    FirebaseUser user;
    Button saveBtn, verified;
    String uID;
    EditText fName, sPhone, password, email;
    String[] arr = {"1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th", "11th", "12th"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_details_activity);
        FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
        Class = (AutoCompleteTextView)
                findViewById(R.id.Class);
        fName = findViewById(R.id.fullName);
        email = findViewById(R.id.email);
        sPhone = findViewById(R.id.phone);
        verified = findViewById(R.id.verified);
        saveBtn = findViewById(R.id.saveBtn);
        mAuth = FirebaseAuth.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        uID = mAuth.getCurrentUser().getUid();
        email.setEnabled(false);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, arr);
        Class.setThreshold(2);
        firebaseFirestore.collection("users").document(getIntent().getStringExtra("uID")).addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                fName.setText(value.getString("fName"));
                Class.setText(value.getString("classes"));
                Class.setAdapter(adapter);
                email.setText(value.getString("email"));
                sPhone.setText(value.getString("phone"));
            }
        });
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DocumentReference documentReference = firebaseFirestore.collection("users").document(getIntent().getStringExtra("uID"));
                Map<String, Object> user = new HashMap<>();
                user.put("fName", fName.getText().toString().trim());
                user.put("email", email.getText().toString().trim());
                user.put("phone", sPhone.getText().toString().trim());
                user.put("classes", Class.getText().toString().trim());
                documentReference.update(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("TAG", "onSuccess: user Profile is created for " + uID);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("TAG", "onFailure: " + e.toString());
                    }
                });
            }
        });
        firebaseFirestore.collection("users").document(getIntent().getStringExtra("uID")).addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                if (value.getString("status").contains("pending")) {
                    verified.setText("Click to Verified");
                    verified.setBackgroundColor(Color.RED);
                    verified.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            DocumentReference documentReference = firebaseFirestore.collection("users").document(getIntent().getStringExtra("uID"));
                            documentReference.update("status", "verified");
                        }
                    });
                } else {
                    verified.setText("Verified");
                    verified.setBackgroundColor(Color.GREEN);
                    verified.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            DocumentReference documentReference = firebaseFirestore.collection("users").document(getIntent().getStringExtra("uID"));
                            documentReference.update("status", "pending");
                        }
                    });
                }
            }
        });

    }
}