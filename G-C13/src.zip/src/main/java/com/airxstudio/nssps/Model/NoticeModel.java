package com.airxstudio.nssps.Model;

public class NoticeModel {
    String title, caption, image, time, desc, NoticeID, UserID;

    public NoticeModel() {
    }

    public NoticeModel(String title, String caption, String image, String time, String desc, String noticeID, String userID) {
        this.title = title;
        this.caption = caption;
        this.image = image;
        this.time = time;
        this.desc = desc;
        NoticeID = noticeID;
        UserID = userID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getNoticeID() {
        return NoticeID;
    }

    public void setNoticeID(String noticeID) {
        NoticeID = noticeID;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }
}
