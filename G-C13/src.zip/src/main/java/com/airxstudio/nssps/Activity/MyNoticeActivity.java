package com.airxstudio.nssps.Activity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.airxstudio.nssps.Adapter.EditNoticesAdapter;
import com.airxstudio.nssps.Adapter.StudentAdapter;
import com.airxstudio.nssps.Model.NoticeModel;
import com.airxstudio.nssps.Model.StudentModel;
import com.airxstudio.nssps.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class MyNoticeActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;
    String uID;
    ArrayList<NoticeModel> noticeModelList;
    EditNoticesAdapter editNoticesAdapter;
    FirebaseFirestore db;
    ProgressBar loadingPB;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_notice_activity);
        recyclerView = findViewById(R.id.SML);
        loadingPB = findViewById(R.id.progressBar1);
        toolbar = findViewById(R.id.toolbar4);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("My Notices");
        db = FirebaseFirestore.getInstance();
        noticeModelList = new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(MyNoticeActivity.this));
        editNoticesAdapter = new EditNoticesAdapter(noticeModelList, MyNoticeActivity.this);
        recyclerView.setAdapter(editNoticesAdapter);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uID = mAuth.getCurrentUser().getUid();
        db.collection("notices").whereEqualTo("UserID",uID).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        if (!queryDocumentSnapshots.isEmpty()) {
                            loadingPB.setVisibility(View.GONE);
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                NoticeModel c = d.toObject(NoticeModel.class);
                                noticeModelList.add(c);
                            }
                            editNoticesAdapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(MyNoticeActivity.this, "No data found in Database", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MyNoticeActivity.this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.search_menu, menu);
        MenuItem searchItem = menu.findItem(R.id.actionSearch);
        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return false;
            }
        });
        return true;
    }

    private void filter(String text) {
        ArrayList<NoticeModel> filteredlist = new ArrayList<>();

        for (NoticeModel item : noticeModelList) {
            if (item.getTitle().toLowerCase().contains(text.toLowerCase())) {
                filteredlist.add(item);
            }
        }
        if (filteredlist.isEmpty()) {
        } else {
            editNoticesAdapter.filterList(filteredlist);
        }
    }
}