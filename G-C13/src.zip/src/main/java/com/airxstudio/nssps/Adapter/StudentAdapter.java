package com.airxstudio.nssps.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.airxstudio.nssps.Activity.StudentDetailsActivity;
import com.airxstudio.nssps.Model.StudentModel;
import com.airxstudio.nssps.R;
import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.ViewHolder> {
    private List<StudentModel> studentModelArrayList;
    private Context context;
    ArrayList<StudentModel> studentList;

    public StudentAdapter(List<StudentModel> studentModelArrayList, Context context) {
        this.studentModelArrayList = studentModelArrayList;
        this.context = context;
        studentList = new ArrayList<>(studentModelArrayList);
    }

    public void filterList(ArrayList<StudentModel> filterllist) {
        studentModelArrayList = filterllist;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.student_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        StudentModel studentModel = studentModelArrayList.get(position);
        holder.fName.setText(studentModel.getfName());
        holder.sClass.setText("("+studentModel.getClasses()+")");
        Glide.with(context).load(studentModel.getImage()).circleCrop().into(holder.sImage);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i =new Intent(context, StudentDetailsActivity.class);
                i.putExtra("uID",studentModel.getuID());
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return studentModelArrayList.size();
    }


    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView sImage;
        TextView fName, sClass;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            sImage = itemView.findViewById(R.id.sImage);
            fName = itemView.findViewById(R.id.fullName);
            sClass = itemView.findViewById(R.id.Class);
        }
    }
}
