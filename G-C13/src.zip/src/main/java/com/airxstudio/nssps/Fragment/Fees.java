package com.airxstudio.nssps.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.airxstudio.nssps.Activity.FeesTransactionActivity;
import com.airxstudio.nssps.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Fees extends Fragment implements PaymentResultListener {
    TextView sName, sClass, sPhone, amount, PaidAmount;
    EditText customAmount;
    Button PayNow;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;
    String uID, feesClass,samount;

    Double leftAmount, totalAmount, feesPaid;
    public static final String TAG1 = "TAG";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_fees, container, false);

       // sName = v.findViewById(R.id.sName);
      //  sClass = v.findViewById(R.id.sClass);
        amount = v.findViewById(R.id.amount);
        customAmount = v.findViewById(R.id.customAmount);
        PayNow = v.findViewById(R.id.PayNow);
        PaidAmount = v.findViewById(R.id.PaidAmount);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uID = mAuth.getCurrentUser().getUid();
        DocumentReference documentReference = fStore.collection("users").document(uID);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
              //  sName.setText(value.getString("fName"));
                String fName = value.getString("fName");
                String sClass = value.getString("classes");
                String sPhone = value.getString("phone");
                String sEmail = value.getString("email");
                feesPaid = value.getDouble("feesAmount");
                PaidAmount.setText(feesPaid.toString());
                DocumentReference documentReference1 = fStore.collection("fees").document(sClass);
                documentReference1.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                    @Override
                    public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                        totalAmount = value.getDouble("fees");
                        leftAmount = totalAmount - feesPaid;
                        amount.setText(leftAmount.toString());
                        customAmount.setText(leftAmount.toString());
                        PayNow.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                samount = customAmount.getText().toString();
                                int amount = Math.round(Float.parseFloat(samount) * 100);
                                Checkout checkout = new Checkout();
                                checkout.setKeyID("rzp_test_Tt8zRSNLajSsNk");
                                JSONObject object = new JSONObject();
                                try {
                                    object.put("name", fName + " (" + sClass + ")");
                                    object.put("description", "New St. Stephen's Public School");
                                    object.put("theme.color", "");
                                    object.put("currency", "INR");
                                    object.put("amount", amount);
                                    object.put("prefill.contact", sPhone);
                                    object.put("prefill.email", sEmail);
                                    checkout.open(getActivity(), object);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    }
                });
            }
        });

        return v;
    }

    @Override
    public void onPaymentSuccess(String s) {
        Intent i = new Intent(getContext(), FeesTransactionActivity.class);
        getContext().startActivity(i);
    }

    @Override
    public void onPaymentError(int i, String s) {
        // on payment failed.
        Toast.makeText(getContext(), "Payment Failed due to error : " + s, Toast.LENGTH_SHORT).show();
    }
}