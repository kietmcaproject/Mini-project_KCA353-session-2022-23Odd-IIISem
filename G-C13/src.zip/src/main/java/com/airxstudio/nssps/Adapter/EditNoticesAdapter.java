package com.airxstudio.nssps.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.airxstudio.nssps.Activity.MyNoticesDetails;
import com.airxstudio.nssps.Model.NoticeModel;
import com.airxstudio.nssps.R;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class EditNoticesAdapter extends RecyclerView.Adapter<EditNoticesAdapter.ViewHolder> {
    private ArrayList<NoticeModel> notices;
    private Context context;

    public EditNoticesAdapter(ArrayList<NoticeModel> notices, Context context) {
        this.notices = notices;
        this.context = context;
    }

    public void filterList(ArrayList<NoticeModel> filterllist) {
        notices = filterllist;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.edit_notice_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NoticeModel noticeModel = notices.get(position);
        holder.noticeTitle.setText(noticeModel.getTitle());
        Glide.with(holder.noticeImg).load(noticeModel.getImage()).into(holder.noticeImg);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, MyNoticesDetails.class);
                i.putExtra("title", noticeModel.getTitle());
                i.putExtra("image", noticeModel.getImage());
                i.putExtra("caption", noticeModel.getCaption());
                i.putExtra("desc", noticeModel.getDesc());
                i.putExtra("NoticeID", noticeModel.getNoticeID());
                i.putExtra("UserID",noticeModel.getUserID());
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return notices.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView noticeImg;
        TextView noticeTitle;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            noticeImg = itemView.findViewById(R.id.sImage);
            noticeTitle = itemView.findViewById(R.id.noticeTitle);

        }
    }
}
