package com.airxstudio.nssps.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;

import com.airxstudio.nssps.Activity.AnnouncementActivity;
import com.airxstudio.nssps.Activity.MyNoticeActivity;

import com.airxstudio.nssps.Activity.NotesActivity;
import com.airxstudio.nssps.Activity.StudyMaterialActivity;
import com.airxstudio.nssps.R;

public class Home extends Fragment {
    LinearLayout annoucementLayout, studyMaterialLayout, attendanceLayout, notesLayout,takeAttendanceLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_home, container, false);
        annoucementLayout = v.findViewById(R.id.annoucementLayout);
        studyMaterialLayout = v.findViewById(R.id.studyMaterialLayout);

        notesLayout = v.findViewById(R.id.notesLayout);
        annoucementLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), AnnouncementActivity.class);
                startActivity(i);
            }
        });

        notesLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), NotesActivity.class);
                startActivity(i);
            }
        });
        studyMaterialLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), StudyMaterialActivity.class);
                startActivity(i);
            }
        });
//        takeAttendanceLayout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i = new Intent(getContext(), TakeAttendanceActivity.class);
//                startActivity(i);
//            }
//        });
        return v;
    }
}