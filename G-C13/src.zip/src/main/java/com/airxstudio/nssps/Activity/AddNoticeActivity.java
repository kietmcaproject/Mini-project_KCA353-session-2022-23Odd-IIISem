package com.airxstudio.nssps.Activity;

import android.Manifest;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.airxstudio.nssps.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class AddNoticeActivity extends AppCompatActivity {
    Uri filepath;
    Bitmap bitmap;
    ImageView uploadImage;
    AutoCompleteTextView role;
    String[] select = {"Notice","Announcement"};
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_notice);
        EditText title = findViewById(R.id.noticeTitle);
        EditText caption = findViewById(R.id.chapterCaption);
        EditText desc = findViewById(R.id.noticeDesc);
        uploadImage = findViewById(R.id.uploadImage);
        role = findViewById(R.id.select);
        Button insert = findViewById(R.id.noticeUpload);
        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        String date = df.format(Calendar.getInstance().getTime());
        TextView time = findViewById(R.id.time);
//        time.setText(date);
        ArrayAdapter<String> roleAdapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, select);
        role.setThreshold(2);
        role.setAdapter(roleAdapter);
        uploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dexter.withActivity(AddNoticeActivity.this)
                        .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                        .withListener(new PermissionListener() {
                            @Override
                            public void onPermissionGranted(PermissionGrantedResponse response) {
                                Intent intent = new Intent(Intent.ACTION_PICK);
                                intent.setType("image/*");
                                startActivityForResult(Intent.createChooser(intent, "Select Image File"), 1);
                            }

                            @Override
                            public void onPermissionDenied(PermissionDeniedResponse response) {

                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                                token.continuePermissionRequest();
                            }
                        }).check();
            }
        });
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final ProgressDialog dialog = new ProgressDialog(AddNoticeActivity.this);
                dialog.setTitle("File Uploader");
                dialog.show();
                FirebaseStorage storage = FirebaseStorage.getInstance();
                final StorageReference uploader = storage.getReference( "Notice"+System.currentTimeMillis());
                uploader.putFile(filepath)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                uploader.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        dialog.dismiss();
                                        Map<String, Object> Notice = new HashMap<>();
                                        Notice.put("title", title.getText().toString().trim());
                                        Notice.put("desc", desc.getText().toString().trim());
                                        Notice.put("caption", caption.getText().toString().trim());
                                        Notice.put("type", role.getText().toString().trim());
                                        Notice.put("time", date);
                                        Notice.put("image", uri.toString());
                                        Notice.put("UserID",firebaseAuth.getCurrentUser().getUid());
                                        Notice.put("NoticeID","");
                                        Notice.put("Time",System.currentTimeMillis());
                                        db.collection("notices")
                                                .add(Notice)
                                                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                                    @Override
                                                    public void onSuccess(DocumentReference documentReference) {
                                                        db.collection("notices").document(documentReference.getId()).update("NoticeID",documentReference.getId());
                                                        Toast.makeText(AddNoticeActivity.this, "Added", Toast.LENGTH_SHORT).show();
                                                    }
                                                })
                                                .addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                    }
                                                });
                                        Toast.makeText(AddNoticeActivity.this, "Uploaded", Toast.LENGTH_LONG).show();
                                        title.setText("");
                                        desc.setText("");
                                        caption.setText("");
                                        uploadImage.setImageResource(R.drawable.notices);
                                    }
                                });
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                                float percent = (100 * snapshot.getBytesTransferred()) / snapshot.getTotalByteCount();
                                dialog.setMessage("Uploaded :" + (int) percent + " %");
                            }
                        });
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 1 && resultCode == RESULT_OK) {
            filepath = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(filepath);
                bitmap = BitmapFactory.decodeStream(inputStream);
                uploadImage.setImageBitmap(bitmap);
            } catch (Exception ex) {
                Toast.makeText(AddNoticeActivity.this, ex.toString(), Toast.LENGTH_SHORT).show();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}