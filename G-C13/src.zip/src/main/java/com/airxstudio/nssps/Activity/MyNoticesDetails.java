package com.airxstudio.nssps.Activity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.airxstudio.nssps.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;

public class MyNoticesDetails extends AppCompatActivity {
    AutoCompleteTextView Class;
    FirebaseAuth mAuth;
    FirebaseUser user;
    Button saveBtn, delete;
    String uID;
    EditText title, caption, desc, email;
    String[] arr = {"1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th", "11th", "12th"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_notices_details);
        FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
        Class = (AutoCompleteTextView)
                findViewById(R.id.Class);
        title = findViewById(R.id.title);
        caption = findViewById(R.id.caption);
        desc = findViewById(R.id.desc);
        delete = findViewById(R.id.delete);
        saveBtn = findViewById(R.id.saveBtn);
        mAuth = FirebaseAuth.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        uID = mAuth.getCurrentUser().getUid();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, arr);
        Class.setThreshold(2);
        firebaseFirestore.collection("notices").document(getIntent().getStringExtra("NoticeID")).addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                title.setText(value.getString("title"));
                Class.setText(value.getString("classes"));
                Class.setAdapter(adapter);
                caption.setText(value.getString("caption"));
                desc.setText(value.getString("desc"));
            }
        });
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DocumentReference documentReference = firebaseFirestore.collection("notices").document(getIntent().getStringExtra("NoticeID"));
                Map<String, Object> user = new HashMap<>();
                user.put("title", title.getText().toString().trim());
                user.put("caption", caption.getText().toString().trim());
                user.put("desc", desc.getText().toString().trim());
                user.put("classes", Class.getText().toString().trim());
                documentReference.update(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("TAG", "onSuccess: user Profile is created for " + uID);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("TAG", "onFailure: " + e.toString());
                    }
                });
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseFirestore.collection("notices").document(getIntent().getStringExtra("NoticeID")).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(MyNoticesDetails.this,"Deleted",Toast.LENGTH_LONG);
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MyNoticesDetails.this,"Something Went Wrong",Toast.LENGTH_LONG);
                    }
                });

            }
        });


    }
}