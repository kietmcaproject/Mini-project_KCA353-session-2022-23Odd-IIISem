package com.airxstudio.nssps.Model;

public class StudentModel {
    String fName, phone, email, classes, role, status, uID, image;
    Double feesAmount;

    public StudentModel() {
    }

    public StudentModel(String fName, String phone, String email, String classes, String role, String status, String uID, Double feesAmount) {
        this.fName = fName;
        this.phone = phone;
        this.email = email;
        this.classes = classes;
        this.role = role;
        this.status = status;
        this.uID = uID;
        this.feesAmount = feesAmount;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getClasses() {
        return classes;
    }

    public void setClasses(String classes) {
        this.classes = classes;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getuID() {
        return uID;
    }

    public void setuID(String uID) {
        this.uID = uID;
    }

    public Double getFeesAmount() {
        return feesAmount;
    }

    public void setFeesAmount(Double feesAmount) {
        this.feesAmount = feesAmount;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
