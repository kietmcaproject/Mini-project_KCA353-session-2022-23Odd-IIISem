package com.airxstudio.nssps.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.airxstudio.nssps.R;
import com.bumptech.glide.Glide;

public class NoticeDetail extends AppCompatActivity {
    ImageView imageView;
    TextView title, desc, caption;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_detail);
        imageView = findViewById(R.id.noticeimg);
        title = findViewById(R.id.title);
        caption = findViewById(R.id.caption);
        desc = findViewById(R.id.desc);
        toolbar = findViewById(R.id.toolbar3);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Notice");
        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        Glide.with(getApplicationContext()).load(getIntent().getStringExtra("image")).into(imageView);
        title.setText(getIntent().getStringExtra("title"));
        desc.setText(getIntent().getStringExtra("desc"));
        caption.setText(getIntent().getStringExtra("caption"));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}