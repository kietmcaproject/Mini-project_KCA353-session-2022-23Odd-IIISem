package com.airxstudio.nssps.Model;

public class NotesModel {
    String title,caption,notesUrl,classes,subject,chapter;

    public NotesModel() {
    }

    public NotesModel(String title, String caption, String notesUrl, String classes, String subject, String chapter) {
        this.title = title;
        this.caption = caption;
        this.notesUrl = notesUrl;
        this.classes = classes;
        this.subject = subject;
        this.chapter = chapter;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getNotesUrl() {
        return notesUrl;
    }

    public void setNotesUrl(String notesUrl) {
        this.notesUrl = notesUrl;
    }

    public String getClasses() {
        return classes;
    }

    public void setClasses(String classes) {
        this.classes = classes;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getChapter() {
        return chapter;
    }

    public void setChapter(String chapter) {
        this.chapter = chapter;
    }
}
