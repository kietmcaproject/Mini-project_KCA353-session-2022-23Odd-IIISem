package com.airxstudio.nssps.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.airxstudio.nssps.Activity.NotesDetail;
import com.airxstudio.nssps.Model.NotesModel;
import com.airxstudio.nssps.R;

import java.util.ArrayList;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.ViewHolder> {
    private ArrayList<NotesModel> notesModelArrayList;
    private Context context;

    public NotesAdapter(ArrayList<NotesModel> notesModelArrayList, Context context) {
        this.notesModelArrayList = notesModelArrayList;
        this.context = context;
    }

    public void filterList(ArrayList<NotesModel> filterllist) {
        notesModelArrayList = filterllist;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public NotesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NotesAdapter.ViewHolder(LayoutInflater.from(context).inflate(R.layout.notes_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull NotesAdapter.ViewHolder holder, int position) {
        NotesModel notesModel = notesModelArrayList.get(position);
        holder.title.setText(notesModel.getTitle());
        holder.caption.setText(notesModel.getCaption());
        holder.classes.setText(notesModel.getClasses());
        holder.subject.setText(notesModel.getSubject());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, NotesDetail.class);
                i.putExtra("notesUrl", notesModel.getNotesUrl());
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return notesModelArrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, caption, classes, subject;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            subject = itemView.findViewById(R.id.caption);
            caption = itemView.findViewById(R.id.classes);
            classes = itemView.findViewById(R.id.subject);
        }
    }
}
