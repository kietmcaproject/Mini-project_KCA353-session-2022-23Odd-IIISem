package com.airxstudio.nssps.Activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.airxstudio.nssps.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class AddNotesActivity extends AppCompatActivity {
    Uri filepath;
    Button selectPdf;
    AutoCompleteTextView subject, classes,type;
    Bitmap bitmap;
    String[] subjectArr = {"Physics", "Chemistry", "Biology", "Maths", "Hindi", "Physical", "Social Science", "Science"};
    String[] classArr = {"1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th", "11th", "12th"};
    String[] typeArr = {"Notes","StudyMaterial"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_notes);
        EditText chapterName = findViewById(R.id.chapterName);
        EditText chapterDesc = findViewById(R.id.chapterCaption);
        selectPdf = findViewById(R.id.uploadPdf);
        subject = findViewById(R.id.subject);
        classes = findViewById(R.id.classes);
        type = findViewById(R.id.type);
        Button insert = findViewById(R.id.noticeUpload);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        String date = df.format(Calendar.getInstance().getTime());
        TextView time = findViewById(R.id.time);
//        time.setText(date);
        ArrayAdapter<String> subjectAdapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, subjectArr);
        subject.setThreshold(2);
        subject.setAdapter(subjectAdapter);
        ArrayAdapter<String> classAdapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, classArr);
        classes.setThreshold(2);
        classes.setAdapter(classAdapter);
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, typeArr);
        type.setThreshold(2);
        type.setAdapter(typeAdapter);
        selectPdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dexter.withActivity(AddNotesActivity.this)
                        .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                        .withListener(new PermissionListener() {
                            @Override
                            public void onPermissionGranted(PermissionGrantedResponse response) {
                                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                                intent.setType("application/pdf");
                                startActivityForResult(Intent.createChooser(intent, "Select Pdf File"), 1);
                            }

                            @Override
                            public void onPermissionDenied(PermissionDeniedResponse response) {

                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                                token.continuePermissionRequest();
                            }
                        }).check();
            }
        });
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final ProgressDialog dialog = new ProgressDialog(AddNotesActivity.this);
                dialog.setTitle("File Uploader");
                dialog.show();
                FirebaseStorage storage = FirebaseStorage.getInstance();
                final StorageReference uploader = storage.getReference("Notes" + System.currentTimeMillis());
                uploader.putFile(filepath)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                uploader.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        dialog.dismiss();
                                        Map<String, Object> StudyMaterial = new HashMap<>();
                                        StudyMaterial.put("title", chapterName.getText().toString().trim());
                                        StudyMaterial.put("caption", chapterDesc.getText().toString().trim());
                                        StudyMaterial.put("subject", subject.getText().toString().trim());
                                        StudyMaterial.put("classes", classes.getText().toString().trim());
                                        StudyMaterial.put("type", type.getText().toString().trim());
                                        StudyMaterial.put("notesUrl", uri.toString());
                                        StudyMaterial.put("Time",System.currentTimeMillis());

                                        db.collection("StudyMaterial")
                                                .add(StudyMaterial)
                                                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                                    @Override
                                                    public void onSuccess(DocumentReference documentReference) {
                                                        Toast.makeText(AddNotesActivity.this, "Added", Toast.LENGTH_SHORT).show();
                                                    }
                                                })
                                                .addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                    }
                                                });
                                        Toast.makeText(AddNotesActivity.this, "Uploaded", Toast.LENGTH_LONG).show();
                                        chapterName.setText("");
                                        chapterDesc.setText("");
                                    }
                                });
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                                float percent = (100 * snapshot.getBytesTransferred()) / snapshot.getTotalByteCount();
                                dialog.setMessage("Uploaded :" + (int) percent + " %");
                            }
                        });
            }
        });
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 1 && resultCode == RESULT_OK) {
            filepath = data.getData();
            try {
                selectPdf.setText("SELECTED");
            } catch (Exception ex) {
                Toast.makeText(AddNotesActivity.this, ex.toString(), Toast.LENGTH_SHORT).show();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

}