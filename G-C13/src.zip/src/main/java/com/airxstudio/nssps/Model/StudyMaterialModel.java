package com.airxstudio.nssps.Model;

public class StudyMaterialModel {
    String title, desc, author, thumb, subject;

    public StudyMaterialModel() {
    }

    public StudyMaterialModel(String title, String desc, String author, String thumb, String subject) {
        this.title = title;
        this.desc = desc;
        this.author = author;
        this.thumb = thumb;
        this.subject = subject;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getThumb() {
        return thumb;
    }

    public void setThumb(String thumb) {
        this.thumb = thumb;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
