package com.airxstudio.nssps.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.airxstudio.nssps.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONException;
import org.json.JSONObject;

public class FeesTransactionActivity extends AppCompatActivity implements PaymentResultListener {
    TextView sName, sClass, sPhone, leftAmountShow, PaidAmount;
    EditText customAmount;
    Button PayNow;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;
    String uID, feesClass, samount;

    Double leftAmount, totalAmount, feesPaid, amount;
    public static final String TAG1 = "TAG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fees_transaction);
        leftAmountShow = findViewById(R.id.amount);
        customAmount = findViewById(R.id.customAmount);
        PayNow = findViewById(R.id.PayNow);
        PaidAmount = findViewById(R.id.PaidAmount);
        if (customAmount.getText().toString().contains("0.0")) {
            PayNow.setEnabled(false);

        }
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uID = mAuth.getCurrentUser().getUid();
        DocumentReference documentReference = fStore.collection("users").document(uID);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                //  sName.setText(value.getString("fName"));
                String fName = value.getString("fName");
                String sClass = value.getString("classes");
                String sPhone = value.getString("phone");
                String sEmail = value.getString("email");
                feesPaid = value.getDouble("feesAmount");
                PaidAmount.setText(feesPaid.toString());
                DocumentReference documentReference1 = fStore.collection("fees").document(sClass);
                documentReference1.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                    @Override
                    public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                        totalAmount = value.getDouble("fees");
                        leftAmount = totalAmount - feesPaid;
                        leftAmountShow.setText(leftAmount.toString());
                        customAmount.setText(leftAmount.toString());
                        PayNow.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                samount = customAmount.getText().toString();
                                amount = Double.valueOf(Math.round(Float.parseFloat(samount)) * 100);
                                Checkout checkout = new Checkout();
                                checkout.setKeyID("rzp_test_Tt8zRSNLajSsNk");
                                JSONObject object = new JSONObject();
                                try {
                                    object.put("name", fName + " (" + sClass + ")");
                                    object.put("description", "New St. Stephen's Public School");
                                    object.put("theme.color", "");
                                    object.put("currency", "INR");
                                    object.put("amount", amount);
                                    object.put("prefill.contact", sPhone);
                                    object.put("prefill.email", sEmail);
                                    checkout.open(FeesTransactionActivity.this, object);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    }
                });
            }
        });

    }
    @Override
    public void onPaymentSuccess(String s) {
        DocumentReference documentReference = fStore.collection("users").document(uID);
        documentReference.update("feesAmount", feesPaid+Double.parseDouble(samount));
    }

    @Override
    public void onPaymentError(int i, String s) {
        // on payment failed.
        Toast.makeText(FeesTransactionActivity.this, "Payment Failed due to error : " + s, Toast.LENGTH_SHORT).show();
    }
}