package com.airxstudio.nssps.Fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.airxstudio.nssps.Activity.AccountDetailsActivity;
import com.airxstudio.nssps.Activity.AddNotesActivity;
import com.airxstudio.nssps.Activity.AddNoticeActivity;
import com.airxstudio.nssps.Activity.FeesTransactionActivity;
import com.airxstudio.nssps.Activity.LoginActivity;
import com.airxstudio.nssps.Activity.StudentActivity;
import com.airxstudio.nssps.Activity.TeacherActivity;
import com.airxstudio.nssps.Activity.MyNoticeActivity;
import com.airxstudio.nssps.R;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class Account extends Fragment {
    Uri filepath;
    ImageView profileImage;
    Bitmap bitmap;
    TextView fName, sClass;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;
    String uID;
    TextView notice, accountDetails, feesTransaction, teacher, student, logout, addNotes;
    LinearLayout studentLayout, teacherLayout, accountDetailLayout, feesTransactionLayout, notesLayout, logoutLayout, noticeLayout,myNoticesLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_account, container, false);
        studentLayout = v.findViewById(R.id.studentLayout);
        teacherLayout = v.findViewById(R.id.teacherLayout);
        accountDetailLayout = v.findViewById(R.id.accountDetailsLayout);
        feesTransactionLayout = v.findViewById(R.id.feeTransactionLayout);
        notesLayout = v.findViewById(R.id.notesLayout);
        logoutLayout = v.findViewById(R.id.logoutLayout);
        noticeLayout = v.findViewById(R.id.noticeLayout);
        myNoticesLayout = v.findViewById(R.id.myNoticeLayout);
        fName = v.findViewById(R.id.fullName);
        sClass = v.findViewById(R.id.Class);
        accountDetails = v.findViewById(R.id.accountDetails);
        feesTransaction = v.findViewById(R.id.feeTransaction);
        addNotes = v.findViewById(R.id.addNotes);
        teacher = v.findViewById(R.id.teacher);
        notice = v.findViewById(R.id.notice);
        profileImage = v.findViewById(R.id.profileImage);
        student = v.findViewById(R.id.student);
        logout = v.findViewById(R.id.logout);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uID = mAuth.getCurrentUser().getUid();
        DocumentReference documentReference = fStore.collection("users").document(uID);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                if (value.getString("role").contains("Student")) {
                    fName.setText(value.getString("fName"));
                    sClass.setText(value.getString("classes") + " Class");
                    Glide.with(getActivity()).load(value.getString("image")).circleCrop().into(profileImage);
                    studentLayout.setVisibility(View.GONE);
                    teacherLayout.setVisibility(View.GONE);
                    notesLayout.setVisibility(View.GONE);
                    noticeLayout.setVisibility(View.GONE);
                    myNoticesLayout.setVisibility(View.GONE);
                    accountDetails.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), AccountDetailsActivity.class);
                            startActivity(i);
                        }
                    });
                    feesTransaction.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), FeesTransactionActivity.class);
                            startActivity(i);
                        }
                    });
                    logout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            mAuth.signOut();
                            Intent i = new Intent(getContext(), LoginActivity.class);
                            startActivity(i);
                        }
                    });
                } else if (value.getString("role").contains("Teacher")) {
                    fName.setText(value.getString("fName"));
                    sClass.setText(value.getString("classes") + " Class Teacher");
                    teacherLayout.setVisibility(View.GONE);
                    feesTransactionLayout.setVisibility(View.GONE);
                    Glide.with(getActivity()).load(value.getString("image")).circleCrop().into(profileImage);

                    accountDetails.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), AccountDetailsActivity.class);
                            startActivity(i);
                        }
                    });
                    myNoticesLayout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), MyNoticeActivity.class);
                            startActivity(i);
                        }
                    });
                    notice.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), AddNoticeActivity.class);
                            startActivity(i);
                        }
                    });
                    addNotes.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), AddNotesActivity.class);
                            startActivity(i);
                        }
                    });
                    student.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), StudentActivity.class);
                            startActivity(i);
                        }
                    });
                    logout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            mAuth.signOut();
                            Intent i = new Intent(getContext(), LoginActivity.class);
                            startActivity(i);
                        }
                    });
                } else if (value.getString("role").contains("Admin")) {
                    fName.setText(value.getString("fName"));
                    sClass.setText("Director");
                    feesTransactionLayout.setVisibility(View.GONE);

                    Glide.with(getActivity()).load(value.getString("image")).circleCrop().into(profileImage);
                    accountDetails.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), AccountDetailsActivity.class);
                            startActivity(i);
                        }
                    });
                    notice.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), AddNoticeActivity.class);
                            startActivity(i);
                        }
                    });
                    myNoticesLayout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), MyNoticeActivity.class);
                            startActivity(i);
                        }
                    });
                    feesTransaction.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), FeesTransactionActivity.class);
                            startActivity(i);
                        }
                    });
                    addNotes.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), AddNotesActivity.class);
                            startActivity(i);
                        }
                    });
                    teacher.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), TeacherActivity.class);
                            startActivity(i);
                        }
                    });
                    student.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getContext(), StudentActivity.class);
                            startActivity(i);
                        }
                    });
                    logout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            mAuth.signOut();
                            Intent i = new Intent(getContext(), LoginActivity.class);
                            startActivity(i);
                        }
                    });
                }
            }
        });

        return v;
    }

}