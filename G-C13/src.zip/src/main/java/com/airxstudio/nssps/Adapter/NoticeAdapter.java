package com.airxstudio.nssps.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.airxstudio.nssps.Activity.NotesDetail;
import com.airxstudio.nssps.Activity.NoticeDetail;
import com.airxstudio.nssps.Model.NoticeModel;
import com.airxstudio.nssps.Model.StudentModel;
import com.airxstudio.nssps.R;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class NoticeAdapter extends RecyclerView.Adapter<NoticeAdapter.ViewHolder> {
    private ArrayList<NoticeModel> notices;
    private Context context;

    public NoticeAdapter(ArrayList<NoticeModel> notices, Context context) {
        this.notices = notices;
        this.context = context;
    }
    public void filterList(ArrayList<NoticeModel> filterllist) {
        notices = filterllist;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.notice_layout_view, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NoticeModel noticeModel = notices.get(position);
        holder.title.setText(noticeModel.getTitle());
        holder.caption.setText(noticeModel.getCaption());
        holder.time.setText(noticeModel.getTime());
        Glide.with(holder.noticeImg).load(noticeModel.getImage()).into(holder.noticeImg);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, NoticeDetail.class);
                i.putExtra("title", noticeModel.getTitle());
                i.putExtra("image", noticeModel.getImage());
                i.putExtra("caption", noticeModel.getCaption());
                i.putExtra("desc", noticeModel.getDesc());
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);            }
        });
    }

    @Override
    public int getItemCount() {
        return notices.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView noticeImg;
        TextView title, time, caption;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            noticeImg = itemView.findViewById(R.id.image);
            title = itemView.findViewById(R.id.title);
            caption = itemView.findViewById(R.id.caption);
            time = itemView.findViewById(R.id.time);
        }
    }
}
