package com.airxstudio.nssps.Activity;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.FragmentTransaction;

import com.airxstudio.nssps.Fragment.Account;
import com.airxstudio.nssps.Fragment.Home;
import com.airxstudio.nssps.Fragment.Meeting;
import com.airxstudio.nssps.Fragment.Notice;
import com.airxstudio.nssps.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;
    String uID;
    DocumentReference documentReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        uID = mAuth.getCurrentUser().getUid();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frameLayout, new Home()).commit();
        documentReference = fStore.collection("users").document(uID);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                if (value.getString("role").contains("Teacher")) {
                    bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                        @Override
                        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                            switch (item.getItemId()) {
                                case R.id.home:
                                    fragmentTransaction.replace(R.id.frameLayout, new Home()).commit();
                                    return true;
                                case R.id.notices:
                                    fragmentTransaction.replace(R.id.frameLayout, new Notice()).commit();
                                    return true;
                                case R.id.meetings:
                                    fragmentTransaction.replace(R.id.frameLayout, new Meeting()).commit();
                                    return true;

                                case R.id.account:
                                    fragmentTransaction.replace(R.id.frameLayout, new Account()).commit();
                                    return true;
                            }
                            return false;
                        }
                    });
                }
                if (value.getString("role").contains("Student")) {
                    bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                        @Override
                        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                            switch (item.getItemId()) {
                                case R.id.home:
                                    fragmentTransaction.replace(R.id.frameLayout, new Home()).commit();
                                    return true;
                                case R.id.notices:
                                    fragmentTransaction.replace(R.id.frameLayout, new Notice()).commit();
                                    return true;
                                case R.id.meetings:
                                    fragmentTransaction.replace(R.id.frameLayout, new Meeting()).commit();
                                    return true;
                                case R.id.account:
                                    fragmentTransaction.replace(R.id.frameLayout, new Account()).commit();
                                    return true;
                            }
                            return false;
                        }
                    });
                }
                if (value.getString("role").contains("Admin")) {
                    bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                        @Override
                        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                            switch (item.getItemId()) {
                                case R.id.home:
                                    fragmentTransaction.replace(R.id.frameLayout, new Home()).commit();
                                    return true;
                                case R.id.notices:
                                    fragmentTransaction.replace(R.id.frameLayout, new Notice()).commit();
                                    return true;
                                case R.id.meetings:
                                    fragmentTransaction.replace(R.id.frameLayout, new Meeting()).commit();
                                    return true;
                                case R.id.account:
                                    fragmentTransaction.replace(R.id.frameLayout, new Account()).commit();
                                    return true;
                            }
                            return false;
                        }
                    });
                }
            }
        });

    }


}