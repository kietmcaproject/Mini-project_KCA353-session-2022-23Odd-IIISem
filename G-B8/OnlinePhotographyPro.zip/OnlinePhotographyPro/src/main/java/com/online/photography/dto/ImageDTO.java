package com.online.photography.dto;

import java.io.InputStream;
import java.sql.Blob;
import java.util.Date;




public class ImageDTO extends BaseBean  {

	
		private String name;
		
		private String photo;
		
		private long uId;
		
		private long count;
		
		private long vid;
		
		private long cId;
		
		
		
		
		



	
	public long getcId() {
			return cId;
		}
		public void setcId(long cId) {
			this.cId = cId;
		}
	public long getVid() {
			return vid;
		}
		public void setVid(long vid) {
			this.vid = vid;
		}
	public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		public String getPhoto() {
			return photo;
		}
		public void setPhoto(String photo) {
			this.photo = photo;
		}
		public long getuId() {
			return uId;
		}
		public void setuId(long uId) {
			this.uId = uId;
		}
		public long getCount() {
			return count;
		}
		public void setCount(long count) {
			this.count = count;
		}
	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
}
