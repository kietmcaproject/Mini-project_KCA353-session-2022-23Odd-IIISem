package com.online.photography.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.apache.log4j.Logger;

import com.online.photography.dto.BaseBean;
import com.online.photography.dto.CompititionDTO;
import com.online.photography.dto.ImageDTO;
import com.online.photography.dto.UserDTO;
import com.online.photography.exception.ApplicationException;
import com.online.photography.exception.DuplicateRecordException;
import com.online.photography.model.CompititionModel;
import com.online.photography.model.ImageModel;
import com.online.photography.util.DataUtility;
import com.online.photography.util.DataValidator;
import com.online.photography.util.PropertyReader;
import com.online.photography.util.ServletUtility;



/**
 * Servlet implementation class SubjectCtl
 */

/**
 * Subject functionality Controller. Performs operation for add, update,
 * delete and get Subject
 * 
 * @author Navigable Set
 * @version 1.0
 * @Copyright (c) Navigable Set
 * 
 */
@WebServlet(name="ImageCtl",urlPatterns={"/ctl/ImageCtl"})
@MultipartConfig(maxFileSize = 16177215) 
public class ImageCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;
	
	private static Logger log=Logger.getLogger(ImageCtl.class);
	

	/**
	 * Loads list and other data required to display at HTML form
	 * 
	 * @param request
	 */
	@Override
	protected void preload(HttpServletRequest request) {
		List list;
		
		CompititionModel model=new CompititionModel();
		
		try {
			list=model.list();
			request.setAttribute("compitionList",list);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Validate input Data Entered By User
	 * 
	 * @param request
	 * @return
	 */
	@Override
    protected boolean validate(HttpServletRequest request) {

		log.debug("SubjectCtl validate method start");
      
        boolean pass = true;

        if ("-----Select-----".equalsIgnoreCase(request.getParameter("name"))) {
			request.setAttribute("name",
					PropertyReader.getValue("error.require", "Compition Type"));
			pass = false;
		}
        
       

        
        
       

        log.debug("SubjectCtl validate method end");
        return pass;
    }
	
	/**
	 * Populates bean object from request parameters
	 * 
	 * @param request
	 * @return
	 */
	@Override
	protected BaseBean populateBean(HttpServletRequest request) {
		log.debug("SubjectCtl populateBean method start");
		ImageDTO bean=new ImageDTO();
		
		
		
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		
		
		bean.setcId(DataUtility.getLong(request.getParameter("name")));
		CompititionModel model=new CompititionModel();
		try {
			CompititionDTO cdto=model.findByPK(bean.getcId());
			bean.setName(cdto.getcType());
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		

		// TODO Auto-generated method stub
		log.debug("SubjectCtl populateBean method end");
	return bean;
	}
	/**
	 * Contains display logic
	 */
	@Override
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("SubjectCtl doGet method start"); 
		String op = DataUtility.getString(request.getParameter("operation"));
	        
	      

	        ServletUtility.forward(getView(), request, response);
	        log.debug("SubjectCtl doGet method end");
    }
	/**
	 * Contains submit logic
	 */
	@Override
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("SubjectCtl doPost method start");
		String op=DataUtility.getString(request.getParameter("operation"));
		ImageDTO bean=(ImageDTO)populateBean(request);
		String savePath = "C:\\Users\\vis08\\Desktop\\Java Project\\OnlinePhotoGraphy\\OnlinePhotographyPro\\src\\main\\webapp\\img"; 
		
		
		HttpSession  session=request.getSession();
		
		UserDTO udto	=(UserDTO)session.getAttribute("user");
		File fileSaveDir = new File(savePath);
        if (!fileSaveDir.exists()) {
            fileSaveDir.mkdir();
        }
			
		Part file=	request.getPart("photo");
		 String fileName = extractFileName(file);
		 
		 file.write(savePath + fileName);
		 
		 String filePath =  fileName;
		 
		ImageModel model=new ImageModel();
		long id=DataUtility.getLong(request.getParameter("id"));
		if(OP_SAVE.equalsIgnoreCase(op)){
			try {
				bean.setuId(udto.getId());
				long pk=model.add(bean,filePath );
				ServletUtility.setSuccessMessage("Data is Successfully Saved", request);
				ServletUtility.forward(getView(), request, response);
			
				  ServletUtility.setBean(bean, request);
			} catch (ApplicationException e) {
				ServletUtility.handleException(e, request, response);
				e.printStackTrace();
				return;
			} catch (DuplicateRecordException e) {
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage("Subject is Already exist", request);
				e.printStackTrace();
			}
		
	
		ServletUtility.forward(getView(), request, response);
		log.debug("SubjectCtl doPost method end");
		}
	}
	
	private String extractFileName(Part file) {
		String contentDisp = file.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length() - 1);
            }
        }
        return "";
	}
	/**
	 * Returns the VIEW page of this Controller
	 * 
	 * @return
	 */
	@Override
	protected String getView() {
		// TODO Auto-generated method stub
		return ORSView.IMAGE_VIEW;
	}}
