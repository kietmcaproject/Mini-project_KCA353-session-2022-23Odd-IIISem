package com.online.photography.model;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.online.photography.dto.CompititionDTO;
import com.online.photography.dto.ImageDTO;
import com.online.photography.dto.UserDTO;
import com.online.photography.dto.VoteDTO;
import com.online.photography.exception.ApplicationException;
import com.online.photography.exception.DatabaseException;
import com.online.photography.exception.DuplicateRecordException;
import com.online.photography.util.JDBCDataSource;

public class ImageModel {

	private static Logger log = Logger.getLogger(CompititionModel.class);

	public Integer nextPK() throws DatabaseException {
		log.debug("Model nextPK Started");
		Connection conn = null;
		int pk = 0;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(ID) FROM image");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				pk = rs.getInt(1);
			}
			rs.close();

		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new DatabaseException("Exception : Exception in getting PK");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model nextPK End");
		return pk + 1;
	}

	public long add(ImageDTO bean, String filePath) throws ApplicationException, DuplicateRecordException {

		Connection conn = null;
		int pk = 0;

		/*
		 * UserDTO existbean = findByLogin(bean.getLogin());
		 * 
		 * if (existbean != null) { throw new
		 * DuplicateRecordException("Login Id already exists"); }
		 */

		try {
			conn = JDBCDataSource.getConnection();
			pk = nextPK();
			// Get auto-generated next primary key
			System.out.println(pk + " in ModelJDBC");
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement("INSERT INTO image VALUES(?,?,?,?,?,?)");
			pstmt.setInt(1, pk);
			pstmt.setString(2, bean.getName());
			pstmt.setString(3, filePath);
			pstmt.setLong(4, bean.getuId());
			pstmt.setLong(5, bean.getCount());
			pstmt.setLong(6, bean.getVid());
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();
		} catch (Exception e) {

			try {
				conn.rollback();
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new ApplicationException("Exception : add rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception : Exception in add User");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		return pk;
	}

	public List list() throws ApplicationException {
		return list(0, 0,null);
	}

	/**
	 * Get List of User with pagination
	 * 
	 * @return list : List of users
	 * @param pageNo
	 *            : Current Page No.
	 * @param pageSize
	 *            : Size of Page
	 * @throws DatabaseException
	 */

	public List list(int pageNo, int pageSize, String name) throws ApplicationException {
		log.debug("Model list Started");
		ArrayList list = new ArrayList();
		StringBuffer sql = new StringBuffer("select * from Image where first_name=?");
		// if page size is greater than zero then apply pagination
		if (pageSize > 0) {
			// Calculate start record index
			pageNo = (pageNo - 1) * pageSize;
			sql.append(" limit " + pageNo + "," + pageSize);
		}

		System.out.println("sql in list user :" + sql);
		Connection conn = null;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1,name);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				ImageDTO bean = new ImageDTO();
				bean.setId(rs.getLong(1));
				bean.setName(rs.getString(2));
				bean.setPhoto(rs.getString(3));
				bean.setuId(rs.getLong(4));
				bean.setCount(rs.getLong(5));
				bean.setVid(rs.getLong(6));

				list.add(bean);
			}
			rs.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting list of users");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}

		log.debug("Model list End");
		return list;

	}

	public ImageDTO findByPK(long pk) throws ApplicationException {
		log.debug("SubjectModel findByPK Started");
		StringBuffer sql = new StringBuffer("SELECT * FROM image WHERE ID=?");
		ImageDTO bean = null;
		Connection conn = null;
		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setLong(1, pk);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new ImageDTO();
				bean.setId(rs.getLong(1));
				bean.setName(rs.getString(2));
				bean.setPhoto(rs.getString(3));
				bean.setuId(rs.getLong(4));
				bean.setCount(rs.getLong(5));
				bean.setVid(rs.getLong(6));
			}
			rs.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting User by pk");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("SubjectModel findByPK End");
		return bean;
	}

	public void update(ImageDTO bean) throws ApplicationException, DuplicateRecordException {

		log.debug("SubjectModel update Started");
		Connection conn = null;
		try {

			conn = JDBCDataSource.getConnection();
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement(
					"UPDATE image SET first_name=?,photo=?,uId=?,count=?,vId=? WHERE ID=?");
			
			pstmt.setString(1, bean.getName());
			pstmt.setString(2, bean.getPhoto());
			pstmt.setLong(3, bean.getuId());
			pstmt.setLong(4, bean.getCount());
			pstmt.setLong(5, bean.getVid());
			pstmt.setLong(6, bean.getId());

			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			try {
				conn.rollback();
			} catch (Exception ex) {
				throw new ApplicationException("Exception : Delete rollback exception " + ex.getMessage());
			}

		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("SubjectModel update End");
	}
	
	
	public Integer nextVotePK() throws DatabaseException {
		log.debug("Model nextPK Started");
		Connection conn = null;
		int pk = 0;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(ID) FROM vote");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				pk = rs.getInt(1);
			}
			rs.close();

		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new DatabaseException("Exception : Exception in getting PK");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model nextPK End");
		return pk + 1;
	}
	
	public long addVote(VoteDTO bean) throws ApplicationException, DuplicateRecordException {

		Connection conn = null;
		int pk = 0;

		/*
		 * UserDTO existbean = findByLogin(bean.getLogin());
		 * 
		 * if (existbean != null) { throw new
		 * DuplicateRecordException("Login Id already exists"); }
		 */

		try {
			conn = JDBCDataSource.getConnection();
			pk = nextVotePK();
			// Get auto-generated next primary key
			System.out.println(pk + " in ModelJDBC");
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement("INSERT INTO vote VALUES(?,?,?)");
			pstmt.setInt(1, pk);
			pstmt.setString(2,bean.getImgName());
			pstmt.setLong(3,bean.getvId());
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();
		} catch (Exception e) {

			try {
				conn.rollback();
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new ApplicationException("Exception : add rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception : Exception in add User");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		return pk;
	}
	
	
	public VoteDTO findByImgVId(String name,long id) throws ApplicationException {
		log.debug("SubjectModel findByPK Started");
		System.out.println("in Model find by nameId");
		StringBuffer sql = new StringBuffer("SELECT * FROM vote WHERE Img_name=? and vid=?");
		VoteDTO bean = null;
		Connection conn = null;
		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setLong(2, id);
			pstmt.setString(1,name);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new VoteDTO();
				bean.setId(rs.getLong(1));
				bean.setImgName(rs.getString(2));
				bean.setvId(rs.getLong(3));
			}
			rs.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting User by pk");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("SubjectModel findByPK End");
		return bean;
	}
	
	public List resultlist(int pageNo, int pageSize) throws ApplicationException {
		log.debug("Model list Started");
		ArrayList list = new ArrayList();
		StringBuffer sql = new StringBuffer("SELECT *FROM image  ORDER BY COUNT DESC");
		// if page size is greater than zero then apply pagination
		if (pageSize > 0) {
			// Calculate start record index
			pageNo = (pageNo - 1) * pageSize;
			sql.append(" limit " + pageNo + "," + pageSize);
		}

		
		System.out.println("sql in list user :"+sql);
		Connection conn = null;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				ImageDTO bean = new ImageDTO();
				bean.setId(rs.getLong(1));
				bean.setName(rs.getString(2));
				bean.setPhoto(rs.getString(3));
				bean.setuId(rs.getLong(4));
				bean.setCount(rs.getLong(5));
				bean.setVid(rs.getLong(6));

				list.add(bean);
			}
			rs.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting list of users");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}

		log.debug("Model list End");
		return list;

	}
	
	public List list(String name) throws ApplicationException {
		log.debug("Model list Started");
		ArrayList list = new ArrayList();
		StringBuffer sql = new StringBuffer("select * from Image where first_name=?");
		// if page size is greater than zero then apply pagination
		
		System.out.println("sql in list user :" + sql);
		Connection conn = null;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1,name);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				ImageDTO bean = new ImageDTO();
				bean.setId(rs.getLong(1));
				bean.setName(rs.getString(2));
				bean.setPhoto(rs.getString(3));
				bean.setuId(rs.getLong(4));
				bean.setCount(rs.getLong(5));
				bean.setVid(rs.getLong(6));

				list.add(bean);
			}
			rs.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting list of users");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}

		log.debug("Model list End");
		return list;

	}
	
	

}
