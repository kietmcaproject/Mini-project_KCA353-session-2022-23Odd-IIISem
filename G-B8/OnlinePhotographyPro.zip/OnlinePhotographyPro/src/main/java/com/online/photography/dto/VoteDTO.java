package com.online.photography.dto;

public class VoteDTO extends BaseBean {

	private String imgName;
	
	private long vId;
	
	
	
	
	
	public String getImgName() {
		return imgName;
	}

	public void setImgName(String imgName) {
		this.imgName = imgName;
	}

	public long getvId() {
		return vId;
	}

	public void setvId(long vId) {
		this.vId = vId;
	}

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}

}
