package com.online.photography.controller;

public interface ORSView {
	
	public String APP_CONTEXT = "/OnlinePhotographyPro";

	public String LAYOUT_VIEW = "/BaseLayout.jsp";
	public String PAGE_FOLDER = "/jsp";

	public String JAVA_DOC_VIEW = APP_CONTEXT + "/doc/index.html";

	public String ERROR_VIEW = PAGE_FOLDER + "/Error.jsp";

	
	
	public String USER_VIEW = PAGE_FOLDER + "/UserView.jsp";	
	public String USER_LIST_VIEW = PAGE_FOLDER + "/UserListView.jsp";
	public String USER_REGISTRATION_VIEW = PAGE_FOLDER + "/UserRegistrationView.jsp";
	
	public String RESULT_LIST_VIEW = PAGE_FOLDER + "/ResultListView.jsp";
	
	

	
	
	
	public String COMPITITION_VIEW=PAGE_FOLDER+"/CompitionView.jsp";
	public String COMPITITION_LIST_VIEW=PAGE_FOLDER+"/CompitionListView.jsp";
	public String IMAGE_VIEW=PAGE_FOLDER+"/ImageView.jsp";
	
	public String IMAGE_LIST_VIEW=PAGE_FOLDER+"/ImageListView.jsp";
	
	
	
		
	
	public String LOGIN_VIEW = PAGE_FOLDER + "/LoginView.jsp";
	public String WELCOME_VIEW = PAGE_FOLDER + "/Welcome.jsp";
	public String CHANGE_PASSWORD_VIEW = PAGE_FOLDER + "/ChangePasswordView.jsp";
	public String MY_PROFILE_VIEW = PAGE_FOLDER + "/MyProfileView.jsp";
	public String FORGET_PASSWORD_VIEW = PAGE_FOLDER + "/ForgetPasswordView.jsp";

	
	

	public String ERROR_CTL = "/ctl/ErrorCtl";


	
	public String USER_CTL = APP_CONTEXT + "/ctl/UserCtl";
	public String USER_LIST_CTL = APP_CONTEXT + "/ctl/UserListCtl";
	
	
	
	
	
	

	

	
	public String COMPITITION_CTL=APP_CONTEXT+"/ctl/CompititionCtl";
    public String COMPITITION_LIST_CTL=APP_CONTEXT+"/ctl/CompititionListCtl";
	
    public String IMAGE_CTL = APP_CONTEXT + "/ctl/ImageCtl";
	public String COURSE_LIST_CTL = APP_CONTEXT + "/ctl/CourseListCtl";
	public String IMAGE_LIST_CTL = APP_CONTEXT + "/ctl/ImageListCtl";
	
	public String RESULT_LIST_CTL = APP_CONTEXT + "/ctl/ResultListCtl";
	
	public String USER_REGISTRATION_CTL = APP_CONTEXT + "/UserRegistrationCtl";
	public String LOGIN_CTL = APP_CONTEXT + "/LoginCtl";
	public String WELCOME_CTL = APP_CONTEXT + "/WelcomeCtl";
	public String LOGOUT_CTL = APP_CONTEXT + "/LoginCtl";
	public String GET_MARKSHEET_CTL = APP_CONTEXT + "/ctl/GetMarksheetCtl";
	public String CHANGE_PASSWORD_CTL = APP_CONTEXT + "/ctl/ChangePasswordCtl";
	public String MY_PROFILE_CTL = APP_CONTEXT + "/ctl/MyProfileCtl";
	public String FORGET_PASSWORD_CTL = APP_CONTEXT + "/ForgetPasswordCtl";
	public String MARKSHEET_MERIT_LIST_CTL = APP_CONTEXT + "/ctl/MarksheetMeritListCtl";



}
