package com.online.photography.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.online.photography.dto.BaseBean;
import com.online.photography.dto.CompititionDTO;
import com.online.photography.exception.ApplicationException;
import com.online.photography.exception.DuplicateRecordException;
import com.online.photography.model.CompititionModel;
import com.online.photography.util.DataUtility;
import com.online.photography.util.DataValidator;
import com.online.photography.util.PropertyReader;
import com.online.photography.util.ServletUtility;



/**
 * Servlet implementation class SubjectCtl
 */

/**
 * Subject functionality Controller. Performs operation for add, update,
 * delete and get Subject
 * 
 * @author Navigable Set
 * @version 1.0
 * @Copyright (c) Navigable Set
 * 
 */
@WebServlet(name="CompititionCtl",urlPatterns={"/ctl/CompititionCtl"})
public class CompititionCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;
	
	private static Logger log=Logger.getLogger(CompititionCtl.class);
	
	/**
	 * Loads list and other data required to display at HTML form
	 * 
	 * @param request
	 */
	
	/**
	 * Validate input Data Entered By User
	 * 
	 * @param request
	 * @return
	 */
	@Override
    protected boolean validate(HttpServletRequest request) {

		log.debug("SubjectCtl validate method start");
      
        boolean pass = true;

        if (DataValidator.isNull(request.getParameter("name"))) {
            request.setAttribute("name", PropertyReader.getValue("error.require", "Name"));
            pass = false;
        }else if (!DataValidator.isName(request.getParameter("name"))) {
			request.setAttribute("name",PropertyReader.getValue("error.name", "Name"));
			pass = false;
		}
        if (DataValidator.isNull(request.getParameter("type"))) {
            request.setAttribute("type", PropertyReader.getValue("error.require", "Compitition Type"));
            pass = false;
        }
        if (DataValidator.isNull(request.getParameter("date"))) {
            request.setAttribute("date", PropertyReader.getValue("error.require", "Compitition Date"));
            pass = false;
        }
        


        log.debug("SubjectCtl validate method end");
        return pass;
    }
	/**
	 * Populates bean object from request parameters
	 * 
	 * @param request
	 * @return
	 */
	@Override
	protected BaseBean populateBean(HttpServletRequest request) {
		log.debug("SubjectCtl populateBean method start");
		CompititionDTO bean=new CompititionDTO();
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		
		bean.setcName(DataUtility.getString(request.getParameter("name")));
		bean.setcType(DataUtility.getString(request.getParameter("type")));
		
		bean.setcDate(DataUtility.getString(request.getParameter("date")));
		
		// TODO Auto-generated method stub
		log.debug("SubjectCtl populateBean method end");
	return bean;
	}
	/**
	 * Contains display logic
	 */
	@Override
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("SubjectCtl doGet method start"); 
		String op = DataUtility.getString(request.getParameter("operation"));
	        

	        ServletUtility.forward(getView(), request, response);
	        log.debug("SubjectCtl doGet method end");
    }
	/**
	 * Contains submit logic
	 */
	@Override
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("SubjectCtl doPost method start");
		String op=DataUtility.getString(request.getParameter("operation"));
		CompititionDTO bean=(CompititionDTO)populateBean(request);
	CompititionModel model=new CompititionModel();
		long id=DataUtility.getLong(request.getParameter("id"));
		if(OP_SAVE.equalsIgnoreCase(op)){
			try {
				
				long pk=model.add(bean);
				ServletUtility.setSuccessMessage("Data is Successfully Saved", request);
				ServletUtility.forward(getView(), request, response);
				  ServletUtility.setBean(bean, request);
			} catch (ApplicationException e) {
				ServletUtility.handleException(e, request, response);
				e.printStackTrace();
				return;
			} catch (DuplicateRecordException e) {
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage("Subject is Already exist", request);
				e.printStackTrace();
			}
		}else if (OP_CANCEL.equalsIgnoreCase(op)) {
				ServletUtility.redirect(ORSView.COMPITITION_LIST_CTL, request, response);
				return;
		}else if (OP_RESET.equalsIgnoreCase(op)) {
			ServletUtility.redirect(ORSView.COMPITITION_CTL, request, response);
			return;
	}
		ServletUtility.forward(getView(), request, response);
		log.debug("SubjectCtl doPost method end");
	}
	
	/**
	 * Returns the VIEW page of this Controller
	 * 
	 * @return
	 */
	@Override
	protected String getView() {
		// TODO Auto-generated method stub
		return ORSView.COMPITITION_VIEW;
	}}
