package com.online.photography.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.online.photography.dto.BaseBean;
import com.online.photography.dto.CompititionDTO;
import com.online.photography.exception.ApplicationException;
import com.online.photography.model.CompititionModel;
import com.online.photography.util.DataUtility;
import com.online.photography.util.PropertyReader;
import com.online.photography.util.ServletUtility;



/**
 * Servlet implementation class SubjectListCtl
 */

/**
 * Subject List functionality Controller. Performs operation for list, search
 * and delete operations of Subject
 * 
 * @author Navigable Set
 * @version 1.0
 * @Copyright (c) Navigable Set
 */

@WebServlet(name = "CompititionListCtl", urlPatterns = { "/ctl/CompititionListCtl" })
public class CompititionListCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;

	private static Logger log = Logger.getLogger(CompititionListCtl.class);
	/**
	 * Populates bean object from request parameters
	 * 
	 * @param request
	 * @return
	 */
	

	/**
	 * Contains Display logics
	 */
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.debug("SubjectListCtl doGet method start");

		System.out.println("SubjectListCtl doGet method start");

		List list = null;
		int pageNo = 1;
		int pageSize = DataUtility.getInt(PropertyReader.getValue("page.size"));

	CompititionModel model = new CompititionModel();
		
		try {

			list = model.list(pageNo, pageSize);

			if (list == null || list.size() == 0) {
				ServletUtility.setErrorMessage("No Record Found", request);
			}

			ServletUtility.setList(list, request);
			ServletUtility.setPageNo(pageNo, request);
			ServletUtility.setPageSize(pageSize, request);
			ServletUtility.forward(getView(), request, response);
		} catch (ApplicationException e) {
			ServletUtility.handleException(e, request, response);
			e.printStackTrace();
			ServletUtility.forward(ORSView.ERROR_VIEW, request, response);
			return;
		}
		log.debug("SubjectListCtl doGet method end");
	}

	/**
	 * Contains Submit logics
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
	}

	/**
	 * Returns the VIEW page of this Controller
	 * 
	 * @return
	 */
	@Override
	protected String getView() {
		// TODO Auto-generated method stub
		return ORSView.COMPITITION_LIST_VIEW;
	}

}
