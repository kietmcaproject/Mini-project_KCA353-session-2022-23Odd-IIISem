package com.vishesh.wastagesolution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WastageSolutionApplicationTests {

	@Test
	void contextLoads() {
	}

}
