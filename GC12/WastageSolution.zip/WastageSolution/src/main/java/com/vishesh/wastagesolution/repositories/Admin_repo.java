package com.vishesh.wastagesolution.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vishesh.wastagesolution.model.Admin;

public interface Admin_repo extends JpaRepository<Admin,Integer> {
	@Query("from Admin a where a.email=?1 and a.password=?2")
	Admin a_login(String email, String password);
}
