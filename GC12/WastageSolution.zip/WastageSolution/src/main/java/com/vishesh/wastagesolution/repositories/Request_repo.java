package com.vishesh.wastagesolution.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.vishesh.wastagesolution.model.Request;

public interface Request_repo extends JpaRepository<Request,Integer> {
	
	@Query("from Request r where r.user.id=?1")
	List<Request> all_request_of_a_user(int id);
	
	@Query("from Request r where r.status=?1")
	List<Request> all_request_based_on_status(String status);
	
	@Query("select count(id) from Request r where r.status=?1")
	int number_of_request_based_on_status(String status);
	
	@Query("select count(id) from Request")
	int total_request();
	
	@Transactional
	@Modifying
	@Query("update Request r set r.status=?2 where r.id=?1")
	int update_status(int id,String status);
	
	@Query("select count(id) from Request r where r.user.id=?1")
	int total_request_of_user(int id);
	
	@Query("select count(id) from Request r where r.user.id=?1 and r.status=?2")
	int request_count_based_on_status(int id,String status);
	
}
	