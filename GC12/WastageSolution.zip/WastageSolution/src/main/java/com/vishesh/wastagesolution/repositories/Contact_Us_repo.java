package com.vishesh.wastagesolution.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vishesh.wastagesolution.model.Contact_Us;

public interface Contact_Us_repo extends JpaRepository<Contact_Us,Integer>{
}
