package com.vishesh.wastagesolution.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vishesh.wastagesolution.model.Category;
import com.vishesh.wastagesolution.repositories.Category_repo;

@RestController
@RequestMapping("/category")
public class Category_Controller {
	
	@Autowired
	Category_repo category;
	
	@PostMapping(value="add",consumes= {"application/json"})
	public Category add_category(@RequestBody Category c) {	
		return category.save(c);
	}
	
	@GetMapping(value="/")
	public Iterable<Category> category(){
		return category.findAll();
	}

}
