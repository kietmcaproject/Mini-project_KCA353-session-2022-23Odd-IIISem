package com.vishesh.wastagesolution.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.vishesh.wastagesolution.model.Category;

public interface Category_repo extends JpaRepository<Category,Integer>{
	
}
