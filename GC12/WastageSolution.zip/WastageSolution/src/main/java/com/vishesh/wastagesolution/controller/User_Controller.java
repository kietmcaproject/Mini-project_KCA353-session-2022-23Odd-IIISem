
package com.vishesh.wastagesolution.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.vishesh.wastagesolution.model.User;
import com.vishesh.wastagesolution.repositories.Request_repo;
import com.vishesh.wastagesolution.repositories.User_Repo;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class User_Controller {
	
	@Autowired
	User_Repo user_repo;
	@Autowired
	Request_repo req_repo;
	
	@GetMapping("/")
	public Iterable<User> allusers() {
		
		Iterable<User> users = user_repo.active_user();
		
		return users;
	}
	
	@PostMapping(value="/add")
	public User saveuser(@ModelAttribute User new_user) {
		
		User u= user_repo.findByEmail(new_user.getEmail()).orElse(null);
		
		if(u==null) {
			u=user_repo.save(new_user);
			return u;
		}
		else {
			throw new ResponseStatusException(400,"Email Already registered", null);
		}
		
	}
	
	@RequestMapping("delete/{id}")
	public int deleteuser(@PathVariable("id") int id) {
		
	    Date date = new Date();
	    String strDateFormat = "yyyy-MM-dd HH:mm:ss";
	    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
	    String time= dateFormat.format(date);
		
	    user_repo.delete_user(id,time);
	    
		return 0;
	}
	
	@PostMapping(value="update")
	public int user_update(@ModelAttribute User user) {
		
		int n = user_repo.update(user.getId(),user.getEmail(),user.getPassword());
		
		return n;
		
	}
	
	@PostMapping(value="/login")
	public Map<String, String> login(@ModelAttribute User new_user) {
		
		
		User u;
		
		if((u=user_repo.u_login(new_user.getEmail(), new_user.getPassword()))!=null) {
			
			Map<String, String> test = new HashMap<>();
			test.put("id",Integer.toString(u.getId()));
			test.put("email",u.getEmail());
			test.put("fname",u.getFname());
			test.put("lname",u.getLname());
			test.put("role","user");
			
			return test;
			
		}else {
			throw new ResponseStatusException(401,"Invalid Credentials!", null);
//			return new HashMap<>();
		}
		
	}
	
	@GetMapping("/dashboard/{id}")
	public Map<String, Integer> dashboard(@PathVariable("id") int id){
		
		Map<String, Integer> dash = new HashMap<>();
		
		dash.put("requests", req_repo.total_request_of_user(id));
		dash.put("coupons", 0);
		dash.put("rejected", req_repo.request_count_based_on_status(id,"rejected"));
		dash.put("completed", req_repo.request_count_based_on_status(id,"completed"));
		
		return dash;
	}
	
}
