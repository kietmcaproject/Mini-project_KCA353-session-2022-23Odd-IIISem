package com.vishesh.wastagesolution;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WastageSolutionApplication {

	public static void main(String[] args) {
		SpringApplication.run(WastageSolutionApplication.class, args);
	}
	
}
