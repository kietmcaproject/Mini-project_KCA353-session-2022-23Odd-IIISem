package com.vishesh.wastagesolution.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vishesh.wastagesolution.model.Address;
import com.vishesh.wastagesolution.model.Request;
import com.vishesh.wastagesolution.repositories.Address_repo;
import com.vishesh.wastagesolution.repositories.Category_repo;
import com.vishesh.wastagesolution.repositories.Request_repo;

@RestController
@RequestMapping(value="request")
public class Request_Controller {
	
	@Autowired
	Request_repo request_repo;
	@Autowired
	Address_repo addr_repo;
	@Autowired
	Category_repo cate_repo;
	
	@GetMapping("/{user_id}")
	public Iterable<Request> users_requests(@PathVariable("user_id") int id){
		
		return request_repo.all_request_of_a_user(id);
		
	}
	
	@PostMapping("/add")
	public Request add_request(@RequestParam("category_id") int category_id,@ModelAttribute Request r, @ModelAttribute Address a) {		
		r.setAddress(addr_repo.save(a));
		r.setCategory(cate_repo.findById(category_id).orElse(null));
		
		return request_repo.save(r);
		
	}
	
	
	
}
