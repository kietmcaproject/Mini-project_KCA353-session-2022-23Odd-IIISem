package com.vishesh.wastagesolution.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.vishesh.wastagesolution.model.User;

public interface User_Repo extends JpaRepository<User,Integer> {
	
	@Transactional
	@Modifying
	@Query("update User u set u.deleted_at=?2 where u.id=?1")
	void delete_user(int id,String time);
	
	@Query("select u from User u where deleted_at=null")
	Iterable<User> active_user();
	
	@Transactional
	@Modifying
	@Query("update User u set u.email=?2, u.password=?3 where id=?1")
	int update(int id, String email, String password);
	
	@Query("from User u where u.email=?1 and u.password=?2 and u.deleted_at=null")
	User u_login(String email, String password);

	Optional<User> findByEmail(String string);
	
	
}
