package com.vishesh.wastagesolution.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.vishesh.wastagesolution.model.Contact_Us;
import com.vishesh.wastagesolution.repositories.Contact_Us_repo;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class Contact_Us_Controller {
	
	@Autowired
	Contact_Us_repo contact_repo;
	
	@RequestMapping("/contact_us")
	public void add_entry(@RequestBody Contact_Us c) {
		if(contact_repo.save(c) != null) {
			throw new ResponseStatusException(200,"Successfully Submitted", null);
		}else {
			throw new ResponseStatusException(500,"Some Server Error!", null);
		}
	}
}
