package com.vishesh.wastagesolution.repositories;

import org.springframework.data.jpa.repository.JpaRepository;	
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.vishesh.wastagesolution.model.Address;

public interface Address_repo extends JpaRepository<Address,Integer> {
	
	@Transactional
	@Modifying
	@Query("update Address a set a.house_no=?2, a.area=?3,a.state=?4,a.city=?5,a.pincode=?6,a.mobile=?6,a.landmark=?7 where a.id=?1")
	int update(int id,String house, String area, String state, String city, int pincode, String mobile, String landmark);
	
	
	@Query("from Address a where a.user_id=?1")
	Iterable<Address> all_user_address(int id);
	
}
