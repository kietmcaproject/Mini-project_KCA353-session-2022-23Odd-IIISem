package com.vishesh.wastagesolution.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.vishesh.wastagesolution.model.Admin;
import com.vishesh.wastagesolution.model.Request;
import com.vishesh.wastagesolution.repositories.Admin_repo;
import com.vishesh.wastagesolution.repositories.Request_repo;

@RestController
@RequestMapping("/admin")
public class Admin_Controller {
	
	@Autowired
	Admin_repo admin_repo;
	@Autowired
	Request_repo request_repo;
	
	@PostMapping("/login")
	private Map<String,String> login(@ModelAttribute Admin admin) {
		
		Admin a;
		a=admin_repo.a_login(admin.getEmail(), admin.getPassword());
		if(a!=null) {
			Map<String, String> map = new HashMap<>();
			map.put("id", String.valueOf(a.getId()));
			map.put("email", a.getEmail());
			map.put("fname", a.getFname());
			map.put("lname", a.getLname());
			map.put("role","admin");
			return map;
		}else {
			throw new ResponseStatusException(400,"Wrong Credentials", null);
		}
		
	}
	
	@GetMapping("/request/{status}")
	private Iterable<Request> all_requested(@PathVariable("status") String status){
		return request_repo.all_request_based_on_status(status);
	}
	
	@GetMapping("/update_request/{id}/{status}")
	private boolean change_status(@PathVariable("id") int id, @PathVariable("status") String status) {
		if(request_repo.update_status(id, status)>0) {
			return true;
		}
		return false;
	}
	
	@GetMapping("/dashboard")
	private Map<String, Integer> dash() {
		
		Map<String, Integer> map = new HashMap<>();
		map.put("completed", request_repo.number_of_request_based_on_status("completed"));
		map.put("requests", request_repo.total_request());
		map.put("rejected", request_repo.number_of_request_based_on_status("rejected"));
		map.put("processing", request_repo.number_of_request_based_on_status("processing"));
		map.put("coupon_alloted", 0);
		map.put("total_coupon", 0);
		return map;
		
		
	}
	
}
