package com.vishesh.wastagesolution.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vishesh.wastagesolution.model.Address;
import com.vishesh.wastagesolution.repositories.Address_repo;

@RestController
@RequestMapping("/address")
public class Address_Controller {
	
	@Autowired
	Address_repo address_repo;
	
	@PostMapping(value="/add")
	public Address add(@RequestBody Address address) {
		return address_repo.save(address);
	}
	
	@GetMapping("/{user_id}")
	public Iterable<Address> address(@PathVariable("user_id") int id){
		return address_repo.all_user_address(id);
	}
}
