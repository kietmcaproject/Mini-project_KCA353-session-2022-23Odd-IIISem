<?php 
	session_start();
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	// $mobile = $_POST['mobile'];
	$password = $_POST['password'];

	if(isset($_POST['submit'])){
		$service_url = 'http://localhost:8080/api/user/add';
		$curl = curl_init($service_url);
		$curl_post_data = array(
				'fname' => $fname,
				'lname' => $lname,
				'email' => $email,
				// 'mobile' => $mobile,
				'password' => $password,
		);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_post_data);
		$curl_response = curl_exec($curl);
		if ($curl_response === false) {
			$info = curl_getinfo($curl);
			curl_close($curl);
			die('error occured during curl exec. Additioanl info: ' . var_export($info));
			exit();
		}
		curl_close($curl);
		$decoded = json_decode($curl_response);

		if(empty($decoded)){
			$_SESSION["alert"]=array(
				"color_class"=>"alert alert-danger alert-dismissible fade show",
				"sign_class"=>"bi-exclamation-octagon",
				"message"=> "No response From the server"
			);
			header("location: register.php");
		}else if(isset($decoded->status)){
			$_SESSION["alert"]=array(
				"color_class"=>"alert alert-danger alert-dismissible fade show",
				"sign_class"=>"bi-exclamation-octagon",
				"message"=> $decoded->message
			);

			header("location: register.php");
		}else{
			$_SESSION["alert"]=array(
				"color_class"=>"alert alert-success alert-dismissible fade show",
				"sign_class"=>"bi-check-circle",
				"message"=> "User registered successfully"
			);
			header("location: regLog.php");
		}      	
	}else{
		header("location: indexx.php");
		exit();	
	}
?>