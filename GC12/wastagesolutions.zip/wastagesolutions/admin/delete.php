<?php
session_start();
// include 'connection.php';
// $conn = OpenCon();

if(isset($_SESSION["admin"])){
	if(isset($_GET['del'])){
		$id = $_GET['del'];
		$service_url = 'http://localhost:8080/api/admin/update_request/'.$id.'/rejected';
		$curl = curl_init($service_url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		$curl_response = curl_exec($curl);
		if ($curl_response === false) {
			$info = curl_getinfo($curl);
			curl_close($curl);
			die('error occured during curl exec. Additioanl info: ' . var_export($info));
		}
		curl_close($curl);
		$decoded = json_decode($curl_response);

		echo "<script> alert ('Rejected'); window.location='newRequest.php' </script>";
	}

	if(isset($_GET['approve'])){
		$id = $_GET['approve'];
		$service_url = 'http://localhost:8080/api/admin/update_request/'.$id.'/processing';
		$curl = curl_init($service_url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		$curl_response = curl_exec($curl);
		if ($curl_response === false) {
			$info = curl_getinfo($curl);
			curl_close($curl);
			die('error occured during curl exec. Additioanl info: ' . var_export($info));
		}
		curl_close($curl);
		$decoded = json_decode($curl_response);

		echo "<script> alert ('Processing'); window.location='processingRequest.php' </script>";
	}
	if(isset($_GET['complete'])){
		$id = $_GET['complete'];
		$service_url = 'http://localhost:8080/api/admin/update_request/'.$id.'/completed';
		$curl = curl_init($service_url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		$curl_response = curl_exec($curl);
		if ($curl_response === false) {
			$info = curl_getinfo($curl);
			curl_close($curl);
			die('error occured during curl exec. Additioanl info: ' . var_export($info));
		}
		curl_close($curl);
		$decoded = json_decode($curl_response);

		echo "<script> alert ('Processing'); window.location='newRequest.php' </script>";
	}
}else{
	echo"<script>alert('You have logged out! Please Sign in again.'); window.location='Login.html'</script>";
    exit();
}

?>

