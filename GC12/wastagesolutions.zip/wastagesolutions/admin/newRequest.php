<?php 
session_start();
  if(isset($_SESSION["admin"])){
    $service_url = 'http://localhost:8080/api/admin/request/requested';
    $curl = curl_init($service_url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $curl_response = curl_exec($curl);
    if ($curl_response === false) {
      $info = curl_getinfo($curl);
      curl_close($curl);
      die('error occured during curl exec. Additioanl info: ' . var_export($info));
    }
    curl_close($curl);
    $decoded = json_decode($curl_response);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin | New Status</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Niceadmin - v2.4.1
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php include("components/header.inc.php"); ?>
  

  <!-- ======= Sidebar ======= -->
  <?php include("components/sidebar.inc.php"); ?>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>NEW REQUEST STATUS</h1>

    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">New Status of Requested task.</h5>

              <!-- Table with hoverable rows -->
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">S.No</th>
                    <th scope="col">Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">Mobile</th>
                    <th scope="col">Address</th>
                    <th scope="col">Status</th>
                    <th scope="col" >Accepted</th>
                    <th scope="col" >Rejected</th>
                  </tr>
                </thead>
                <tbody>
                  <!-- <tr>
                    <th scope="row">1</th>
                    <td>Brandon Jacob</td>
                    <td>Designer</td>
                    <td>28</td>
                    <td>dlw</td>
                    <td>Completed</td>
                    <td><a><i class="bi bi-trash"></i></a></td>
                  </tr> -->
                  
                  <?php
		
			// print_r($decoded);
			foreach ($decoded as $key=>$value) 
			{
	?>	
			<tr>
				<td><?php echo $key+1; ?></td>
				<td><?php echo $value->name; ?></td>
				<td><?php echo $value->description; ?></td>
				<td><?php echo $value->mobile; ?></td>
				<td><?php echo $value->address->house_no .' '. $value->address->area . ','.$value->address->pincode; ?></td>
				<!-- <td><?php ?></td> -->
				<td><?php echo $value->status?></td>
				<?php
					if($value->status == "requested"){
				?>
				<td>
					<a href="delete.php?approve=<?php echo $value->id; ?>"><i class="bi bi-check-square-fill"></i></a>
			
				</td>
				<td>
					
					<a href="delete.php?del=<?php echo $value->id; ?>" ><i class="bi bi-trash-fill"></i></a>
				</td>
				<?php
			    }
				?>
		    </tr>
	<?php    
			}
    ?>
                </tbody>
              </table>
              <!-- End Table with hoverable rows -->

            </div>
          </div>


        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include("components/footer.inc.php"); ?>

</body>

</html>
<?php
  }else{
    echo '<script>alert("Please login first"); window.location.href="/wastagesolutions/admin"; </script>';
  }
?>