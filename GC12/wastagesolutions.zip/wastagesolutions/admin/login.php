
<?php
    if(isset($_POST['submit'])){
        // echo 'helloworlld';
        session_start();
        $email=$_POST['email'];
        $password=$_POST['password'];
        $duration = 60000;
        
        if(empty ($email)||empty ($password)){
            echo"<script>alert('Please fill all the credentials.'); window.location='indexx.php'</script>";
            exit();
        }else{

            $service_url = 'http://localhost:8080/api/admin/login';
            $curl = curl_init($service_url);
            $curl_post_data = array(
                    'email' => $email,
                    'password' => $password,
            );
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_post_data);
            $curl_response = curl_exec($curl);
            if ($curl_response === false) {
                $info = curl_getinfo($curl);
                curl_close($curl);
                die('error occured during curl exec. Additioanl info: ' . var_export($info));
                exit();
            }
            curl_close($curl);
            $decoded = json_decode($curl_response);

            if(empty($decoded)){
                echo '<script>alert("No response from server"); window.location.href="/wastagesolutions/admin/";</script>';
            }else if (isset($decoded->status)){
                echo '<script>alert("'.$decoded->message.'"); window.location.href="/wastagesolutions/admin/";</script>';
            }else{
                // print_r($decoded->id);

                $_SESSION["admin"]=array(
                    "id"=>$decoded->id,
                    "email"=>$decoded->email,
                    "fname"=>$decoded->fname,
                    "lname"=>$decoded->lname
                );
                header("location: dashboard.php");
                // echo '<script>alert("admin registered successfully"); window.location.href="indexx.html";</script>';
            }      	
            
        }
    }else{
        header("location: indexx.php");
        exit(); 
    }    

?>