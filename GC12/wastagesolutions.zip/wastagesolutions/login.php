
<?php
    if(!isset($_SESSION))
        session_start();
    
    if(isset($_POST['submit'])){

        $email=$_POST['email'];
        $password=$_POST['password'];
        $duration = 60000;
        
        if(empty ($email)||empty ($password)){
            echo"<script>alert('Please fill all the credentials.'); window.location='regLog.php'</script>";
            exit();
        }else{

            $service_url = 'http://localhost:8080/api/user/login';
            $curl = curl_init($service_url);
            $curl_post_data = array(
                    'email' => $email,
                    'password' => $password,
            );
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_post_data);
            $curl_response = curl_exec($curl);
            if ($curl_response === false) {
                $info = curl_getinfo($curl);
                curl_close($curl);
                die('error occured during curl exec. Additioanl info: ' . var_export($info));
                exit();
            }
            curl_close($curl);
            $decoded = json_decode($curl_response);

            if(empty($decoded)){
                // echo '<script>alert("No response from the server"); window.location.href="regLog.php";</script>';
                $_SESSION["alert"]=array(
                    "color_class"=>"alert alert-danger alert-dismissible fade show",
                    "sign_class"=>"bi-exclamation-octagon",
                    "message"=> "No response from the server"
                );
                header("location: regLog.php");
            }else if(isset($decoded->status)){
                // echo '<script>alert(""); window.location.href="regLog.php";</script>';
                $_SESSION["alert"]=array(
                    "color_class"=>"alert alert-danger alert-dismissible fade show",
                    "sign_class"=>"bi-exclamation-octagon",
                    "message"=> $decoded->message
                );
                header("location: regLog.php");
            }
            else{
                // print_r($decoded->message);

                $_SESSION["user"]=array(
                    "id"=>$decoded->id,
                    "email"=>$decoded->email,
                    "fname"=>$decoded->fname,
                    "lname"=>$decoded->lname,
                    "start"=>time(),
                    "duration"=>$duration
                );
                $_SESSION["alert"]=array(
                    "color_class"=>"alert alert-success alert-dismissible fade show",
                    "sign_class"=>"bi-check-circle",
                    "message"=> "LoggedIn Successfully"
                );
                header("location: user/dashboard.php");
                // echo '<script>alert("User logged in"); window.location.href="user/index.php?id=smdbhjdfcbdjfcwsdhudyvjhkjwshvd";</script>';
            }      	
            
        }
    }else{
        header("location: regLog.php");
        exit(); 
    }    

?>