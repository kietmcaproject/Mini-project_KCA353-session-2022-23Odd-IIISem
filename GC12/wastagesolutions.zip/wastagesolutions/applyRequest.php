<?php error_reporting();
session_start();

$name=$_POST['name'];
$category = 1;
$description = $_POST['description'];
$mobile = $_POST['mobile'];
$house_no = $_POST['house_no'];
$area = $_POST['area'];
$pincode = $_POST['pincode'];
$state = $_POST['state'];
$city = $_POST['city'];
$landmark = $_POST['landmark'];
	// create connection
	if(isset($_POST['submit'])){
		// if(empty($name)||empty($mobile)||empty($area)||empty($person)){
		// 	header("location: Apply Request1.php?apply=empty");
		// 	exit();
		// }
		// else{
			// if(!preg_match('/^[0-9]{10}+$/', $mobile)){
			// 	header("location: Apply Request1.php?apply=mob");
			// 	exit();
			// }
			// else{
			$service_url = 'http://localhost:8080/api/request/add';
            $curl = curl_init($service_url);
            $curl_post_data = array(
                    'user_id' => $_SESSION["user"]["id"],
					'name' =>$name,
                    'category_id' => $category,
					'description'=>$description,
					'mobile' => $mobile,
					'house_no'=>$house_no,
					'area'=>$area,
					'pincode'=>$pincode,
					'state'=>$state,
					'city'=>$city,
					'landmark'=>$landmark,
					'status'=>'requested',
            );
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_post_data);
            $curl_response = curl_exec($curl);
            if ($curl_response === false) {
                $info = curl_getinfo($curl);
                curl_close($curl);
                die('error occured during curl exec. Additioanl info: ' . print_r($info));
                exit();
            }
            curl_close($curl);
            $decoded = json_decode($curl_response);
			if(empty($decoded)){
				print_r("NO data");
			}else{
				echo "<script>alert('request saved'); window.location.href='user/requestform.php';</script>";
			}
			// }

		// }
	}
?>