<?php

if(isset($_SESSION["loggedin"])){
	$duration=$_SESSION["loggedin"]["duration"];
	$start = $_SESSION["loggedin"]["start"];
	if((time()-$start)>$duration){
		unset($_SESSION["loggedin"]["duration"]);
		unset($_SESSION["loggedin"]["start"]);
		unset($_SESSION["name"]);
		unset($_SESSION["loggedin"]);
		echo"<script>alert('Seesion has been expired! Please login again'); window.location='Login.html'</script>";
        exit();
	}else{
		if(isset($_GET['del'])){
			$id = $_GET['del'];
			$sql = "delete from detail where id='$id'";
			$result = mysqli_query($conn,$sql);
			
			echo "<script> alert ('Record Deleted'); window.location='view status.php' </script>";
		}
	}
}else{
	echo"<script>alert('You have logged out! Please Sign in again.'); window.location='Login.html'</script>";
    exit();
}

?>