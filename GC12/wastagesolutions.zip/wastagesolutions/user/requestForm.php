<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>User Request Form</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    
    <link href="assets/css/style.css" rel="stylesheet">

   
</head>

<body>

    <!-- ======= Header ======= -->
    <?php include("components/header.inc.php"); ?>


    <!-- ======= Sidebar ======= -->
    <?php include("components/sidebar.inc.php"); ?>


    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Request Form</h1>
        </div>
        <!-- End Page Title -->
        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <form class="row g-3" action="../applyRequest.php" method="POST">
                                <div class="col-md-12 ">
                                    <div class="form-floating mt-4">
                                        <input type="text" class="form-control" placeholder="Full Name" name="name" id="name" required>
                                        <label for="name">Full Name</label>
                                    </div>
                                </div>
                                <div class="col-md-12 ">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" placeholder="Email" name="email" id="email" required>
                                        <label for="email">Email</label>
                                    </div>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" placeholder="House Number" name="house_no" id="house_no" required>
                                        <label for="house_no">House Number</label>
                                    </div>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" placeholder="Area" name="area" id="area" required>
                                        <label for="area">Area</label>
                                    </div>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" placeholder="Landmark" name="landmark" id="landmark" required>
                                        <label for="landmark">Landmark</label>
                                    </div>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" placeholder="Pincode" name="pincode" id="pincode" maxlength="6" minlength="6" required>
                                        <label for="pincode">Pincode</label>
                                    </div>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" placeholder="City" name="city" id="city" required>
                                        <label for="city">City</label>
                                    </div>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" placeholder="State" name="state" id="state" required>
                                        <label for="state">State</label>
                                    </div>
                                </div>
                                <div class="col-12 ">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" placeholder="Mobile" name="mobile" id="mobile" maxlength="10" minlength="10" required>
                                        <label for="mobile">Mobile</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <textarea class="form-control" placeholder="Address" name="description" id="description" style="height: 100px;" required></textarea>
                                        <label for="description">Decription about wastage</label>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                    <button type="reset" class="btn btn-secondary">Reset</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php include("components/footer.inc.php"); ?>
</body>

</html>